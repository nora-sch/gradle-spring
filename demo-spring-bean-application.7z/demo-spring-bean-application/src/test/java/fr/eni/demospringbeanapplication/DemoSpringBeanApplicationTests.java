package fr.eni.demospringbeanapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSpringBeanApplicationTests {

    @Test
    void contextLoads() {
    }

}
