package fr.eni.demospringbootwebmvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoSpringBootWebMvcApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoSpringBootWebMvcApplication.class, args);
    }

}
