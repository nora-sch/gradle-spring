package fr.eni.demospringbootwebmvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSpringBootWebMvcApplicationTests {

    @Test
    void contextLoads() {
    }

}
