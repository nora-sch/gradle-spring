package fr.eni.springcore.module03democouplagefortfaible;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Module03DemoCouplageFortFaibleApplication {

    public static void main(String[] args) {
        SpringApplication.run(Module03DemoCouplageFortFaibleApplication.class, args);
    }

}
