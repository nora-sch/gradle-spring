package fr.eni.springcore.module03democouplagefortfaible.orchestreFaible;

public interface Instrument {
    void afficher();
    void jouer();
}
