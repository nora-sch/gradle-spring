package fr.eni.springcore.module03democouplagefortfaible.orchestreForte;

public class Violon {
    public void afficher(){System.out.println("Je suis un violon...");}
    public void jouer(){
        System.out.println("ZIN ZIN ZIN");
    }
}
