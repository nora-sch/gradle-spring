package fr.eni.springcore.module03democouplagefortfaible;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Module03DemoCouplageFortFaibleApplicationTests {

    @Test
    void contextLoads() {
    }

}
